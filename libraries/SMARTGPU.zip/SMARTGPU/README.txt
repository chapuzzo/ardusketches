
/**************************************************************/
  SMARTGPU ARDUINO 1.0 LIBRARY

This library help the user to communicate the SMARTGPU BOARD with the arduino board, be sure to check pinout while mounting the SMARTGPU!


Where to place this entire folder(SMARTGPU)?

place it in the arduino PC root:

arduino-00XX\arduino-00XX\libraries\SMARTGPU

restart arduino to recognize the library and enjoy!

be sure to check out all the SMARTGPU examples 100% ready to compile and load in our website
/**************************************************************/

SMARTGPU board:
http://www.vizictechnologies.com/#/desarrollo/4554296549

Software:
http://www.vizictechnologies.com/#/software-demos/4554679040


VIZIC TECHNOLOGIES Copyright 2011

www.vizictechnologies.com
/**************************************************************/
