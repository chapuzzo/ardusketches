
Optimized digital functions from 
  http://code.google.com/p/digitalwritefast
